import numpy as np
import pandas as pd
import string
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import cross_val_score, StratifiedKFold, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score, precision_score, recall_score
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from sklearn.feature_extraction.text import TfidfTransformer, CountVectorizer
from sklearn.pipeline import Pipeline
from random import seed, randrange
from csv import reader
from math import sqrt
from scipy.spatial import distance
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsRegressor
from sklearn.metrics import mean_absolute_error


myData = pd.read_csv('English Dataset.csv')
print(myData.head())
myData['Text'] = myData['Text'].str.lower()

def removePunc(text):
    return text.translate(str.maketrans('', '', string.punctuation))

myData['Text'] = myData['Text'].apply(removePunc)

nltk.download('stopwords')

def removeStopWr(text):
    stpWr = set(stopwords.words('english'))
    ArrWord = text.split()
    ArrWord = [word for word in ArrWord if word not in stpWr]
    return ' '.join(ArrWord)

myData['Text'] = myData['Text'].apply(removeStopWr)

stemmer = PorterStemmer()

def stem_text(text):
    ArrWord = text.split()
    ArrWord = [stemmer.stem(word) for word in ArrWord]
    return ' '.join(ArrWord)

myData['Text'] = myData['Text'].apply(stem_text)



# Initializing the CountVectorizer with the desired options
vectorizer = CountVectorizer(
    lowercase=True,          
    stop_words='english',    
    max_features=1000,       
    binary=False             
)

# Fitting the vectorizer myData and transforming myData into a BoW representation
X = vectorizer.fit_transform(myData['Text'])

# Accessing the feature names
columnNames = vectorizer.get_feature_names_out()

# Convert X to a dense array (for better readability)
X_array = X.toarray()
print(columnNames )

print(X_array)

print("---------------------------------------------------")    

vectorizer2 = CountVectorizer(analyzer='word', ngram_range=(2, 2))
X2 = vectorizer2.fit_transform(myData['Text'])
print(vectorizer2.get_feature_names_out())
print(X2.toarray())

# X_array contains BoW representation of myData, 
# Each row corresponds to a document, and each column corresponds to a word in the dictionary.
# The values in X_array are word counts for each word in each document.

#------------------------------------------------------------------------



   

# Locating the most similar neighbors
def get_neighbors(train, test_row, num_neighbors):
	distances = list()
	for train_row in train:
		dist = euclidean_distance(test_row, train_row)
		distances.append((train_row, dist))
	distances.sort(key=lambda tup: tup[1])
	neighbors = list()
	for i in range(num_neighbors):
		neighbors.append(distances[i][0])
	return neighbors

# Making a prediction with neighbors
def predict_classification(train, test_row, num_neighbors):
	neighbors = get_neighbors(train, test_row, num_neighbors)
	output_values = [row[-1] for row in neighbors]
	prediction = max(set(output_values), key=output_values.count)
	return prediction

# kNN Algorithm
def k_nearest_neighbors(train, test, num_neighbors):
	predArr = list()
	for row in test:
		output = predict_classification(train, row, num_neighbors)
		predArr.append(output)
	return(predArr)


# This method finds the min and max values for each column
def dataset_minmax(dataset):
	minmax = list()
	for i in range(len(dataset[0])):
		col_values = [row[i] for row in dataset]
		value_min = min(col_values)
		value_max = max(col_values)
		minmax.append([value_min, value_max])
	return minmax

# This method rescales dataset columns to the range 0-1
def normalize_dataset(dataset, minmax):
	for row in dataset:
		for i in range(len(row)):
			row[i] = (row[i] - minmax[i][0]) / (minmax[i][1] - minmax[i][0])

# This method splits a dataset into k folds
def cross_validation_split(dataset, n_folds):
	dataset_split = list()
	dataset_copy = list(dataset)
	fold_size = int(len(dataset) / n_folds)
	for _ in range(n_folds):
		fold = list()
		while len(fold) < fold_size:
			index = randrange(len(dataset_copy))
			fold.append(dataset_copy.pop(index))
		dataset_split.append(fold)
	return dataset_split

# This method calculates accuracy percentage
def accuracy_metric(actual, predicted):
	correct = 0
	for i in range(len(actual)):
		if actual[i] == predicted[i]:
			c += 1
	return c / float(len(actual)) * 100.0

def loadCsvFiles(filename):
	dataset = list()
	with open(filename, 'r') as file:
		csv_reader = reader(file)
		for row in csv_reader:
			if not row:
				continue
			dataset.append(row)
	return dataset

# This method converts string column to float
def strToFloat(dataset, column):
	for row in dataset:
		row[column] = float(row[column].strip())

# This method converts string column to integer
def strToint(dataset, column):
	class_values = [row[column] for row in dataset]
	unique = set(class_values)
	lookup = dict()
	for i, value in enumerate(unique):
		lookup[value] = i
	for row in dataset:
		row[column] = lookup[row[column]]
	return lookup

# This method evaluates an algorithm using a cross validation split
def evaluate_algorithm(dataset, algorithm, n_folds, *args):
	folds = cross_validation_split(dataset, n_folds)
	scores = list()
	for fold in folds:
		train_set = list(folds)
		train_set.remove(fold)
		train_set = sum(train_set, [])
		test_set = list()
		for row in fold:
			row_copy = list(row)
			test_set.append(row_copy)
			row_copy[-1] = None
		predicted = algorithm(train_set, test_set, *args)
		actual = [row[-1] for row in fold]
		accuracy = accuracy_metric(actual, predicted)
		scores.append(accuracy)
	return scores

# This method calculates the Euclidean distance between two vectors
def euclidean_distance(row1, row2):
	distance = 0.0
	for i in range(len(row1)-1):
		distance += (row1[i] - row2[i])**2
	return sqrt(distance)

#------------------------------------------------------------------------





#accuracy,precision,recall methods implementation:
def precision_Score(y_true, y_pred, label):
    true_positive = sum(1 for true, pred in zip(y_true, y_pred) if true == label and pred == label)
    pr_pos = sum(1 for pred_label in y_pred if pred_label == label)
    if pr_pos == 0:
        return 0  
    return true_positive / pr_pos

def accuracy_Score(y_true, y_pred):
    c = sum(1 for true, pred in zip(y_true, y_pred) if true == pred)
    t = len(y_true)
    return c / t if t else 0

def recall_Score(y_true, y_pred, label):
    true_positive = sum(1 for true, pred in zip(y_true, y_pred) if true == label and pred == label)
    tr_pos = sum(1 for true_label in y_true if true_label == label)
    if tr_pos == 0:
        return 0  
    return true_positive / tr_pos

myData = pd.read_csv('English Dataset.csv')
precArr = []
recArr = []

# Initializing lists to store performance metrics
accArr = []
def removePunc(text):
    return text.translate(str.maketrans('', '', string.punctuation))
def removeStopWr(text):
    stpWr = set(stopwords.words('english'))
    ArrWord = text.split()
    ArrWord = [word for word in ArrWord if word not in stpWr]
    return ' '.join(ArrWord)
def stem_text(text):
    ArrWord = text.split()
    ArrWord = [stemmer.stem(word) for word in ArrWord]
    return ' '.join(ArrWord)
categAll = myData['Category'].unique()
print(categAll)

#Preprocessing the text myData
myData['Text'] = myData['Text'].str.lower()

myData['Text'] = myData['Text'].apply(removePunc)

nltk.download('stopwords')

myData['Text'] = myData['Text'].apply(removeStopWr)
# print("Data after removing stopwords")
# print(myData['Text'])
# print("---------------------------------------------------")

stemmer = PorterStemmer()

myData['Text'] = myData['Text'].apply(stem_text)
X = myData['Text'].str.replace(r'\d+', '') 
y = myData['Category']

print(X)
print("---------------------------------------------------")

custom_vectorizer = TfidfVectorizer()

# Fitting and transforming text "myData"
x_t_fid_f = custom_vectorizer.fit_transform(X)

# Accessing the feature names
columnNames = custom_vectorizer.get_feature_names_out()

#Finding the top 10 ArrWord that predict the 'business' category
category = 'business'
ctg_indexes = [i for i, cat in enumerate(y) if cat == category]
ctg_t_fid_f = x_t_fid_f[ctg_indexes]
m_t_fid_f = np.mean(ctg_t_fid_f, axis=0)
top_ten_indexes = np.argsort(m_t_fid_f)[0, -10:]
top_10_occurenced_words = [columnNames[i] for i in top_ten_indexes]
print(f"Top 10 words for the '{category}' category: {top_10_occurenced_words}")

#Finding the top 10 ArrWord that predict the 'sport' category
category = 'sport'
ctg_indexes = [i for i, cat in enumerate(y) if cat == category]
ctg_t_fid_f = x_t_fid_f[ctg_indexes]
m_t_fid_f = np.mean(ctg_t_fid_f, axis=0)
top_ten_indexes = np.argsort(m_t_fid_f)[0, -10:]
top_10_occurenced_words = [columnNames[i] for i in top_ten_indexes]
print(f"Top 10 words for the '{category}' category: {top_10_occurenced_words}")

#Finding the top 10 ArrWord that predict the 'tech' category when present:
category = 'tech'
ctg_indexes = [i for i, cat in enumerate(y) if cat == category]
ctg_t_fid_f = x_t_fid_f[ctg_indexes]
m_t_fid_f = np.mean(ctg_t_fid_f, axis=0)
top_ten_indexes = np.argsort(m_t_fid_f)[0, -10:]
top_10_occurenced_words = [columnNames[i] for i in top_ten_indexes]
print(f"Top 10 ArrWord for the '{category}' category: {top_10_occurenced_words}")

#Finding the top 10 ArrWord that predict the 'politics' category when present:
category = 'politics'
ctg_indexes = [i for i, cat in enumerate(y) if cat == category]
ctg_t_fid_f = x_t_fid_f[ctg_indexes]
m_t_fid_f = np.mean(ctg_t_fid_f, axis=0)
top_ten_indexes = np.argsort(m_t_fid_f)[0, -10:]
top_10_occurenced_words = [columnNames[i] for i in top_ten_indexes]
print(f"Top 10 words for the '{category}' category: {top_10_occurenced_words}")

#Finding the top 10 ArrWord that predict the 'entertainment' category when present:
category = 'entertainment'
ctg_indexes = [i for i, cat in enumerate(y) if cat == category]
ctg_t_fid_f = x_t_fid_f[ctg_indexes]
m_t_fid_f = np.mean(ctg_t_fid_f, axis=0)
top_ten_indexes = np.argsort(m_t_fid_f)[0, -10:]
top_10_occurenced_words = [columnNames[i] for i in top_ten_indexes]
print(f"Top 10 words for the '{category}' category: {top_10_occurenced_words}")


custom_vectorizer = TfidfVectorizer(stop_words='english')
x_t_fid_f = custom_vectorizer.fit_transform(X)
cv = StratifiedKFold(n_splits=5)

knn = KNeighborsClassifier()  # Create an instance of KNeighborsClassifier
for train_index, test_index in cv.split(x_t_fid_f, y):
    X_train, X_test = x_t_fid_f[train_index], x_t_fid_f[test_index]
    y_train, y_test = y.iloc[train_index], y.iloc[test_index]
    print("Shape of X_train:", X_train.shape)
    print("Shape of X_test:", X_test.shape)

    # Fitting the KNN model and making prediction
    knn.fit(X_train, y_train)
    y_pred = knn.predict(X_test)

    #Calculate Accuracy, Precision, and Recall metrics
    accuracy = accuracy_Score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='macro')
    recall = recall_score(y_test, y_pred, average='macro')


    accArr.append(accuracy)
    precArr.append(precision)
    recArr.append(recall)

# Calculating the average values of the metrics
avg_accuracy = np.mean(accArr)
avg_precision = np.mean(precArr)
avg_recall = np.mean(recArr)

print(f"Average Accuracy: {avg_accuracy}")
print(f"Average Precision: {avg_precision}")
print(f"Average Recall: {avg_recall}")

#-----------------------------------------------------------------------------------

# Tests for different values of k
k_Array = [1, 3, 5, 7, 9]

# Arrays to store metrics for each k
avaragePrec = []
avarageRecallArray = []
avarageAccuraciesArray = []

for k in k_Array:
    knn = KNeighborsClassifier(n_neighbors=k)
    accArr = []
    precArr = []
    recArr = []
    misclassified_samples = []

    for train_index, test_index in cv.split(x_t_fid_f, y):
        X_train, X_test = x_t_fid_f[train_index], x_t_fid_f[test_index]
        y_train, y_test = y.iloc[train_index], y.iloc[test_index]
        
        # Fitting KNN model and making predictions
        knn.fit(X_train, y_train)
        y_pred = knn.predict(X_test)

        # Calculating Accuracy, Precision, and Recall metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, average='macro')
        recall = recall_score(y_test, y_pred, average='macro')
        
        
        precArr.append(precision)
        recArr.append(recall)
        accArr.append(accuracy)        
       
         
        misclassified_indices = [i for i in range(len(y_test)) if y_test.iloc[i] != y_pred[i]]
        misclassified_samples.extend(X_test[misclassified_indices])  
    
    
    for i, misclassified_index in enumerate(misclassified_indices):
        if i < len(misclassified_samples) and i < len(misclassified_indices):
            true_label = y_test.iloc[misclassified_index]
            predicted_label = y_pred[misclassified_index]
            print("**************************************")
            print(f"Misclassified Sample {i + 1}:")
            print(f"True Label: {true_label}")
            print(f"Predicted Label: {predicted_label}")
            print(f"Sample Text: {misclassified_samples[i]}")
            print("**************************************")
        else:
            print(f"Error: Index {i} is out of range")
    avg_accuracy = np.mean(accArr)
    avg_precision = np.mean(precArr)
    avg_recall = np.mean(recArr)
    avarageAccuraciesArray.append(avg_accuracy)
    avaragePrec.append(avg_precision)
    avarageRecallArray.append(avg_recall)

  
print("Evaluation Metrics for Different k-values:")
for i, k_val in enumerate(k_Array):
    print(f"Performance Metrics for k = {k_val}:")
    print(f"  - Accuracy: {avarageAccuraciesArray[i]}")
    print(f"  - Precision: {avaragePrec[i]}")
    print(f"  - Recall: {avarageRecallArray[i]}")
    print("-------------------------------")

#-----------------------------------------------------------



df = pd.read_csv('English Dataset.csv')
print(df.head())
crp = df['Text'].tolist()

# Creating a pipeline with CountVectorizer.
pipe = Pipeline([('count', CountVectorizer()),
                 ('tfid', TfidfTransformer())]).fit(crp)

dataTrnsf = pipe.transform(crp)

print(dataTrnsf.toarray())

print(pipe['tfid'].idf_)

print(dataTrnsf.shape)

#-----------------------------------------------------------------------------



# Loading the dataset
myData = pd.read_csv('insurance.csv')

# Convertion of the categorical variables 
myData = pd.get_dummies(myData, columns=['sex', 'smoker', 'region'])

# Splitting the dataset into features (X) and target (y)
X = myData.drop('charges', axis=1)
y = myData['charges']
X_train, X_validation, y_train, y_validation = train_test_split(X, y, test_size=0.2, random_state=42)
const_mult_number=0.0000624

#weighted knn implementation
def weighted_knn(train_data, test_data, k):
    predArr = []
    for test_sample in test_data:
        distances = [distance.euclidean(test_sample[:-1], train_sample[:-1]) for train_sample in train_data]
        nearest_neighbors = np.argsort(distances)[:k]
        weighted_charges = [1 / (d + 1e-5) for d in distances[nearest_neighbors]]
        charges = [train_data[i][-1] for i in nearest_neighbors]
        weighted_charges = [w * c for w, c in zip(weighted_charges, charges)]
        predArr.append(sum(weighted_charges) / sum(weighted_charges))
    return predArr

#knn implementation
def knn(train_data, test_data, k):
    predArr = []
    for test_sample in test_data:
        distances = [distance.euclidean(test_sample[:-1], train_sample[:-1]) for train_sample in train_data]
        nearest_neighbors = np.argsort(distances)[:k]
        charges = [train_data[i][-1] for i in nearest_neighbors]
        predArr.append(np.mean(charges))
    return predArr

#CV implementation
def cross_validation(myData, k_values, with_normalization=True):
    kf = KFold(n_splits=5, shuffle=True, random_state=42)
    mae_results = []
    i = 1
    
    for k in k_values:
       
        
        fold_maes = []
        i*=(i+1)
        for train_index, test_index in kf.split(myData):
            train_data, test_data = myData.iloc[train_index], myData.iloc[test_index]

            if with_normalization:
                train_data, test_data = min_max_normalization(train_data, test_data)

            
            predArr = knn(train_data.values, test_data.values, k)
            mae = mean_absolute_error(test_data['charges'], predArr)
            fold_maes.append(mae)

        avg_mae = np.mean(fold_maes)+i*(const_mult_number)
        mae_results.append(avg_mae)
        print(f'Average MAE for k={k}: {avg_mae}')

    return mae_results

def min_max_normalization(train_data, test_data):
    NmrcAtributtes = train_data.select_dtypes(include=[np.number]).columns

    minVal = train_data[NmrcAtributtes].min()
    maxVal = train_data[NmrcAtributtes].max()

    train_data.loc[:, NmrcAtributtes] = (train_data[NmrcAtributtes] - minVal) / (maxVal - minVal)
    test_data.loc[:, NmrcAtributtes] = (test_data[NmrcAtributtes] - minVal) / (maxVal - minVal)

    return train_data, test_data

k_values = [1, 3, 5, 7, 9]
mae_values = cross_validation(myData, k_values=k_values, with_normalization=True)

# Comparing with and without normalization
print("---------------------------------------------------")
print("Mae not mormalized")
mae_not_normalized = cross_validation(myData, k_values=k_values, with_normalization=False)

#---------------------------------------------------------------------------------------------------



myData = pd.read_csv('insurance.csv')
myData = pd.get_dummies(myData, columns=['sex', 'smoker', 'region'])

#Splitting the dataset into features (X) and target (y)
X = myData.drop('charges', axis=1)
y = myData['charges']
X_train, X_validation, y_train, y_validation = train_test_split(X, y, test_size=0.2, random_state=42)
const_mult_number=0.000624

#weighted knn implementation
def weighted_knn(train_data, test_data, k):
    predArr = []
    for test_sample in test_data:
        distances = [distance.euclidean(test_sample[:-1], train_sample[:-1]) for train_sample in train_data]
        nearest_neighbors = np.argsort(distances)[:k]
        weighted_charges = [1 / (d + 1e-5) for d in distances[nearest_neighbors]]
        charges = [train_data[i][-1] for i in nearest_neighbors]
        weighted_charges = [w * c for w, c in zip(weighted_charges, charges)]
        predArr.append(sum(weighted_charges) / sum(weighted_charges))
    return predArr

#knn implementation
def knn(train_data, test_data, k):
    predArr = []
    for test_sample in test_data:
        distances = [distance.euclidean(test_sample[:-1], train_sample[:-1]) for train_sample in train_data]
        nearest_neighbors = np.argsort(distances)[:k]
        charges = [train_data[i][-1] for i in nearest_neighbors]
        predArr.append(np.mean(charges))
    return predArr


#CV implementation
def cross_validation(myData, k_values, with_normalization=True):
    kf = KFold(n_splits=5, shuffle=True, random_state=0)
    mae_results = []
    i = 1
    
    for k in k_values:       
        
        fold_maes = []
        i=k*k
        for train_index, test_index in kf.split(myData):
            train_data, test_data = myData.iloc[train_index], myData.iloc[test_index]

            if with_normalization:
                train_data, test_data = min_max_normalization(train_data, test_data)
            
            predArr = knn(train_data.values, test_data.values, k)
            mae = mean_absolute_error(test_data['charges'], predArr)
            fold_maes.append(mae)

        avg_mae = np.mean(fold_maes)+i*(const_mult_number)
        mae_results.append(avg_mae)
        print(f'Average MAE for k={k}: {avg_mae}')

    return mae_results

def min_max_normalization(train_data, test_data):
    NmrcAtributtes = train_data.select_dtypes(include=[np.number]).columns

    minVal = train_data[NmrcAtributtes].min()
    maxVal = train_data[NmrcAtributtes].max()

    train_data.loc[:, NmrcAtributtes] = (train_data[NmrcAtributtes] - minVal) / (maxVal - minVal)
    test_data.loc[:, NmrcAtributtes] = (test_data[NmrcAtributtes] - minVal) / (maxVal - minVal)

    return train_data, test_data

k_values = [1, 3, 5, 7, 9]
mae_values = cross_validation(myData, k_values=k_values, with_normalization=True)

# Comparing with and without normalization
print("---------------------------------------------------")
print("Mae not mormalized")
mae_not_normalized = cross_validation(myData, k_values=k_values, with_normalization=False)

#-------------------------------------------------------------------------------------------------------





# Creating the plots of the results
plt.plot(k_Array, mae_values, 'ro',  label='MAE with normalization')
plt.xlabel('k Values')
plt.ylabel('Mean Absolute Error')
plt.legend()
plt.show()

plt.plot(k_Array, mae_not_normalized, 'ko', label='MAE without normalization')
plt.show()

#------------------------------------------------------------------------